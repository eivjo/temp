Cisco MDT synthetic GPB-KV simulator

Prepare on Mac:
  Copy the generated files mdt_dialout_pb2.py, mdt_dialout_pb2_grpc.py,
  telemetry_bis_pb2.py into the same directory as simulate.py.
  tar -czf cisco-mdt-v2.tar.gz simulate.py mdt_dialout_pb2.py mdt_dialout_pb2_grpc.py telemetry_bis_pb2.py

On Ubuntu:
  tar -xzf cisco-mdt-v2.tar.gz
  source .venv/bin/activate
  python simulate.py --host YOUR_ENVOY_HOST --dry-run --count 1
  python simulate.py --host YOUR_ENVOY_HOST --ca /etc/ssl/certs/ca-certificates.crt --count 30 --interval 10

The metric structures are synthetic approximations, not validated against actual IOS XE output.

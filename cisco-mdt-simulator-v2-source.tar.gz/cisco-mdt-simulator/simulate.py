#!/usr/bin/env python3
"""Synthetic Cisco IOS XE MDT GPB-KV dial-out generator.

Requires generated mdt_dialout_pb2{,_grpc}.py and telemetry_bis_pb2.py.
"""
import argparse
import random
import sys
import threading
import time
from pathlib import Path

import grpc
from google.protobuf import json_format
import mdt_dialout_pb2
import mdt_dialout_pb2_grpc
import telemetry_bis_pb2

PATHS = {
    'cpu': 'Cisco-IOS-XE-process-cpu-oper:cpu-usage/cpu-utilization',
    'mem': 'Cisco-IOS-XE-memory-oper:memory-statistics/memory-statistic',
    'if': 'Cisco-IOS-XE-interfaces-oper:interfaces/interface/statistics',
}


def scalar(name, value):
    result = {'name': name}
    if isinstance(value, bool):
        result['boolValue'] = value
    elif isinstance(value, str):
        result['stringValue'] = value
    elif isinstance(value, int):
        result['uint64Value' if value >= 0 else 'sint64Value'] = str(value)
    elif isinstance(value, float):
        result['doubleValue'] = value
    else:
        raise TypeError(type(value))
    return result


def obj(name, *children):
    return {'name': name, 'fields': list(children)}


def record(*children):
    return {'fields': list(children)}


def telemetry(source, path, rows):
    body = {
        'nodeIdStr': source,
        'subscriptionIdStr': 'ubuntu-mdt-simulator',
        'encodingPath': path,
        'msgTimestamp': str(int(time.time() * 1000)),
        'dataGpbkv': rows,
    }
    return json_format.ParseDict(body, telemetry_bis_pb2.Telemetry())


def payloads(source, rng, state, selected):
    if 'cpu' in selected:
        cpu = rng.randint(12, 87)
        yield 'cpu', telemetry(source, PATHS['cpu'], [record(
            obj('content', scalar('five-seconds', cpu),
                scalar('one-minute', cpu), scalar('five-minutes', max(0, cpu - 3)))
        )]), {'cpu': cpu}

    if 'mem' in selected:
        used = rng.randint(450_000_000, 750_000_000)
        total = 1_000_000_000
        yield 'mem', telemetry(source, PATHS['mem'], [record(
            obj('keys', scalar('name', 'Processor')),
            obj('content', scalar('used-memory', used),
                scalar('free-memory', total - used))
        )]), {'used': used, 'free': total - used}

    if 'if' in selected:
        for interface in ('GigabitEthernet1/0/1', 'GigabitEthernet1/0/2'):
            counters = state.setdefault(interface, {
                'in-octets': 1_000_000,
                'out-octets': 2_000_000,
                'in-unicast-pkts': 10_000,
                'out-unicast-pkts': 20_000,
            })
            for key in counters:
                counters[key] += rng.randint(1000, 25000) if 'octets' in key else rng.randint(5, 150)
            yield 'if', telemetry(source, PATHS['if'], [record(
                obj('keys', scalar('name', interface)),
                obj('content', *(scalar(k, v) for k, v in counters.items()))
            )]), {'interface': interface, **counters}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', required=True)
    p.add_argument('--port', type=int, default=443)
    p.add_argument('--ca', default=None, help='CA bundle PEM, e.g. /etc/ssl/certs/ca-certificates.crt')
    p.add_argument('--count', type=int, default=30, help='Number of cycles')
    p.add_argument('--interval', type=float, default=10)
    p.add_argument('--source', default='ubuntu-mdt-test')
    p.add_argument('--metrics', default='cpu,mem,if', help='Comma-separated: cpu,mem,if')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--dry-run', action='store_true', help='Serialize locally without network')
    args = p.parse_args()
    selected = set(args.metrics.split(','))
    if not selected or selected - set(PATHS):
        p.error('metrics must be a comma-separated subset of cpu,mem,if')
    if args.count < 1 or args.interval < 0:
        p.error('count must be >=1 and interval >=0')

    rng = random.Random(args.seed)
    state = {}
    stopped = threading.Event()

    def messages():
        req_id = 0
        for cycle in range(args.count):
            if stopped.is_set():
                return
            for kind, msg, values in payloads(args.source, rng, state, selected):
                req_id += 1
                data = msg.SerializeToString()
                request = mdt_dialout_pb2.MdtDialoutArgs()
                request.ReqId = req_id
                request.data = data
                print(f'cycle={cycle+1} type={kind} bytes={len(data)} values={values}', flush=True)
                yield request
            if cycle + 1 < args.count and stopped.wait(args.interval):
                return

    if args.dry_run:
        for _ in messages():
            pass
        print('Local serialization OK')
        return

    roots = Path(args.ca).read_bytes() if args.ca else None
    channel = grpc.secure_channel(
        f'{args.host}:{args.port}',
        grpc.ssl_channel_credentials(root_certificates=roots),
    )
    try:
        grpc.channel_ready_future(channel).result(timeout=15)
        print('gRPC channel READY', flush=True)
        stub = mdt_dialout_pb2_grpc.gRPCMdtDialoutStub(channel)
        responses = stub.MdtDialout(messages())
        for response in responses:
            print('Server response:', response, flush=True)
        print('gRPC stream completed', flush=True)
    except grpc.RpcError as exc:
        print(f'gRPC ERROR: {exc.code()} {exc.details()}', file=sys.stderr)
        sys.exit(1)
    except grpc.FutureTimeoutError:
        print('gRPC connection timed out', file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print('Interrupted')
    finally:
        stopped.set()
        channel.close()


if __name__ == '__main__':
    main()

#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'logmon-config.json'),
    [string]$StateDirectory = (Join-Path $env:ProgramData 'windows_exporter\logmon\state'),
    [string]$ResetProfile,
    [string]$ResetWatcher
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$inv = [Globalization.CultureInfo]::InvariantCulture
function Epoch { return [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }
function Write-Atomic([string]$Path, [string]$Content) {
    $tmp = $Path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($tmp, $Content, $utf8)
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($tmp, $Path, ($Path + '.bak')) }
        else { [IO.File]::Move($tmp, $Path) }
    } finally { if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) } }
}
function Escape-Label([string]$Value) {
    return $Value.Replace('\','\\').Replace('"','\"').Replace("`r",'\n').Replace("`n",'\n')
}
function Labels([string]$Profile, [string]$Watcher = '') {
    $s = 'profile="' + (Escape-Label $Profile) + '"'
    if ($Watcher) { $s += ',watcher="' + (Escape-Label $Watcher) + '"' }
    return '{' + $s + '}'
}
function Hash-Prefix($Stream, [int]$Count) {
    if ($Count -eq 0) { return '' }
    $saved = $Stream.Position
    try {
        $Stream.Position = 0
        $bytes = New-Object byte[] $Count
        $got = 0
        while ($got -lt $Count) {
            $n = $Stream.Read($bytes,$got,$Count-$got)
            if ($n -eq 0) { throw 'File changed while reading its prefix.' }
            $got += $n
        }
        $sha = [Security.Cryptography.SHA256]::Create()
        try { return [Convert]::ToBase64String($sha.ComputeHash($bytes)) }
        finally { $sha.Dispose() }
    } finally { $Stream.Position = $saved }
}
# Windows file identity detects replacement/rotation even if content starts identically.
if ($env:OS -eq 'Windows_NT' -and -not ('LogmonNativeFile' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class LogmonNativeFile {
    [StructLayout(LayoutKind.Sequential)] private struct Info {
        public uint Attributes;
        public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write;
        public uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    private static extern bool GetFileInformationByHandle(SafeFileHandle h, out Info i);
    public static string Identity(SafeFileHandle h) {
        Info i;
        if (!GetFileInformationByHandle(h, out i))
            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        return i.Volume + ":" + i.IndexHigh + ":" + i.IndexLow;
    }
}
'@
}
[IO.Directory]::CreateDirectory($StateDirectory) | Out-Null
$lock = $null
try {
    try {
        $lock = [IO.File]::Open((Join-Path $StateDirectory 'collector.lock'),
            [IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    } catch [IO.IOException] { throw 'Another collector/reset is running, or the state directory cannot be locked.' }
    $cfg = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($cfg.InitialRead -notin @('Start','End')) { throw 'InitialRead must be Start or End.' }
    if ($cfg.MaxBytesPerFilePerRun -lt 1024 -or $cfg.MaxBytesPerFilePerRun -gt 67108864) {
        throw 'MaxBytesPerFilePerRun must be between 1024 and 67108864.'
    }
    if ($cfg.PendingFilesThreshold -lt 0) { throw 'PendingFilesThreshold cannot be negative.' }
    $decoder = [Text.Encoding]::GetEncoding($cfg.Encoding,
        [Text.EncoderFallback]::ExceptionFallback,[Text.DecoderFallback]::ExceptionFallback)
    $statePath = Join-Path $StateDirectory 'state.json'
    if (Test-Path -LiteralPath $statePath) {
        $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.Schema -ne 1) { throw 'Unsupported state schema. State was not changed.' }
    } else { $state = [pscustomobject]@{Schema=1; BaselineEstablished=$false; Profiles=@()} }
    # Build objects and compile expressions before reading any file.
    $work = @()
    $names = @{}
    foreach ($profile in $cfg.Profiles) {
        if ($names.ContainsKey($profile.Name)) { throw "Duplicate profile: $($profile.Name)" }
        $names[$profile.Name] = $true
        $ps = @($state.Profiles | Where-Object { $_.Name -eq $profile.Name })
        if ($ps.Count -gt 1) { throw 'Duplicate profile in state.' }
        if ($ps.Count -eq 0) {
            $pstate = [pscustomobject]@{Name=$profile.Name; LastSuccess=0; Files=@(); Rules=@(); PendingKnown=0; Pending=0; PendingObserved=0}
            $state.Profiles = @($state.Profiles) + $pstate
        } else { $pstate = $ps[0] }
        $rules = @()
        $ruleNames = @{}
        foreach ($rule in $profile.EventRules) {
            if ($ruleNames.ContainsKey($rule.Name)) { throw 'Duplicate watcher name.' }
            $ruleNames[$rule.Name] = $true
            $opts = [Text.RegularExpressions.RegexOptions]::CultureInvariant
            if ($rule.IgnoreCase) { $opts = $opts -bor [Text.RegularExpressions.RegexOptions]::IgnoreCase }
            $rx = New-Object Text.RegularExpressions.Regex($rule.Pattern,$opts,[TimeSpan]::FromSeconds(1))
            $rs = @($pstate.Rules | Where-Object { $_.Name -eq $rule.Name })
            if ($rs.Count -eq 0) {
                $rstate = [pscustomobject]@{Name=$rule.Name; Total=0; LastMatch=0; Active=0}
                $pstate.Rules = @($pstate.Rules) + $rstate
            } else { $rstate = $rs[0] }
            $rules += [pscustomobject]@{Config=$rule; Regex=$rx; State=$rstate}
        }
        $work += [pscustomobject]@{Config=$profile; State=$pstate; Rules=$rules; Success=1; MatchedFiles=0; Backlog=0}
    }
    if ([bool]$ResetProfile -ne [bool]$ResetWatcher) { throw 'Specify both ResetProfile and ResetWatcher.' }
    if ($ResetProfile) {
        $target = @($work | Where-Object { $_.Config.Name -eq $ResetProfile })
        if ($target.Count -ne 1) { throw 'Reset profile not found.' }
        $ruleTarget = @($target[0].Rules | Where-Object { $_.Config.Name -eq $ResetWatcher })
        if ($ruleTarget.Count -ne 1) { throw 'Reset watcher not found. Pending-file state cannot be reset manually.' }
        $ruleTarget[0].State.Active = 0
        Write-Host "Reset $ResetProfile / $ResetWatcher. New unread matches can activate it again."
    }
    foreach ($item in $work) {
        $profile = $item.Config; $pstate = $item.State
        try {
            # Literal directory + wildcard filename; no recursive scanning.
            $dir = [IO.Path]::GetDirectoryName($profile.Path)
            $filter = [IO.Path]::GetFileName($profile.Path)
            $files = @(Get-ChildItem -LiteralPath $dir -Filter $filter -File -ErrorAction Stop | Sort-Object FullName)
            $item.MatchedFiles = $files.Count
            if ($files.Count -eq 0) { throw "No files matched $($profile.Path)" }
            foreach ($file in $files) {
                $stream = $null
                try {
                    $share = [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete
                    $stream = [IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,$share)
                    $length = $stream.Length
                    if ($env:OS -eq 'Windows_NT') { $identity = [LogmonNativeFile]::Identity($stream.SafeFileHandle) }
                    else { $identity = $file.FullName } # Non-Windows test fallback; production uses Windows file ID.
                    $saved = @($pstate.Files | Where-Object { $_.Path -eq $file.FullName })
                    $new = $saved.Count -eq 0
                    if ($new) {
                        $offset = 0L
                        if (-not $state.BaselineEstablished -and $cfg.InitialRead -eq 'End') { $offset = $length }
                        $fs = [pscustomobject]@{Path=$file.FullName; Identity=$identity; Offset=$offset; PrefixLength=0; PrefixHash=''}
                    } else {
                        $fs = $saved[0]
                        $offset = [long]$fs.Offset
                        $rotated = $fs.Identity -ne $identity -or $length -lt $offset
                        if (-not $rotated -and $fs.PrefixLength -gt 0) {
                            $rotated = $length -lt $fs.PrefixLength -or (Hash-Prefix $stream $fs.PrefixLength) -ne $fs.PrefixHash
                        }
                        if ($rotated) { $offset = 0L }
                    }
                    $prefixLength = [int][Math]::Min(256,$length)
                    $prefixHash = Hash-Prefix $stream $prefixLength
                    $stream.Position = $offset
                    $toRead = [int][Math]::Min([long]$cfg.MaxBytesPerFilePerRun,$length-$offset)
                    $data = New-Object byte[] $toRead
                    $got = 0
                    while ($got -lt $toRead) {
                        $n = $stream.Read($data,$got,$toRead-$got)
                        if ($n -eq 0) { throw 'File was truncated during collection; retry next run.' }
                        $got += $n
                    }
                    # Commit only complete LF-terminated lines; retain partial last line for next run.
                    $end = $got-1
                    while ($end -ge 0 -and $data[$end] -ne 10) { $end-- }
                    $consumed = $end+1
                    if ($got -eq $cfg.MaxBytesPerFilePerRun -and $consumed -eq 0) {
                        throw 'Line exceeds MaxBytesPerFilePerRun; increase limit or inspect log.'
                    }
                    $text = $decoder.GetString($data,0,$consumed).TrimStart([char]0xFEFF)
                    # Stage matches before updating persistent state, avoiding partial commits on regex errors.
                    $hits = @{}; $pending = $null
                    foreach ($r in $item.Rules) { $hits[$r.Config.Name] = 0L }
                    foreach ($line in ($text -split "`n")) {
                        foreach ($r in $item.Rules) {
                            if ($r.Regex.IsMatch($line)) { $hits[$r.Config.Name]++ }
                        }
                        if ($profile.PendingFiles -and $line -match 'Antall filer til behandling\s*:\s*(\d+)\b') {
                            $pending = [long]::Parse($Matches[1],$inv)
                        }
                    }
                    $now = Epoch
                    foreach ($r in $item.Rules) {
                        if ($hits[$r.Config.Name] -gt 0) {
                            $r.State.Total = [long]$r.State.Total + $hits[$r.Config.Name]
                            $r.State.LastMatch = $now; $r.State.Active = 1
                        }
                    }
                    if ($null -ne $pending) {
                        $pstate.Pending = $pending; $pstate.PendingKnown = 1; $pstate.PendingObserved = $now
                    }
                    $fs.Offset = $offset+$consumed; $fs.Identity = $identity
                    $fs.PrefixLength = $prefixLength; $fs.PrefixHash = $prefixHash
                    if ($new) { $pstate.Files = @($pstate.Files) + $fs }
                    $item.Backlog += $length-$fs.Offset
                } catch {
                    $item.Success = 0
                    Write-Warning "$($profile.Name) / $($file.Name): $($_.Exception.Message)"
                } finally { if ($null -ne $stream) { $stream.Dispose() } }
            }
            if ($item.Success -eq 1) { $pstate.LastSuccess = Epoch }
        } catch {
            $item.Success = 0
            Write-Warning "$($profile.Name): $($_.Exception.Message)"
        }
    }
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $specs = @{
        'logmon_collector_last_run_timestamp_seconds'=@('gauge','Last completed collector run, Unix seconds.');
        'logmon_profile_collection_success'=@('gauge','1 if all matching files were read successfully.');
        'logmon_profile_last_success_timestamp_seconds'=@('gauge','Last successful profile scan, Unix seconds.');
        'logmon_profile_matched_files'=@('gauge','Number of files currently matching a profile.');
        'logmon_profile_unread_bytes'=@('gauge','Unread bytes including any incomplete trailing line.');
        'logmon_event_active'=@('gauge','Latched event alarm. Cleared only by explicit reset.');
        'logmon_event_matches_total'=@('counter','Matched log lines since state initialization.');
        'logmon_event_last_match_timestamp_seconds'=@('gauge','When a matching line was collected, not its original log time.');
        'logmon_pending_files'=@('gauge','Latest pending-file count parsed from SIHdd.');
        'logmon_pending_files_known'=@('gauge','1 after a valid pending-file count has been observed.');
        'logmon_pending_files_observed_timestamp_seconds'=@('gauge','Collection time of latest pending-file observation.');
        'logmon_pending_files_threshold'=@('gauge','Alarm threshold; active when pending files exceeds this value.')
    }
    foreach ($name in ($specs.Keys | Sort-Object)) {
        $lines.Add('# HELP '+$name+' '+$specs[$name][1]); $lines.Add('# TYPE '+$name+' '+$specs[$name][0])
    }
    $lines.Add('logmon_collector_last_run_timestamp_seconds '+(Epoch))
    foreach ($item in $work) {
        $l = Labels $item.Config.Name; $s = $item.State
        $lines.Add('logmon_profile_collection_success'+$l+' '+$item.Success)
        $lines.Add('logmon_profile_last_success_timestamp_seconds'+$l+' '+$s.LastSuccess)
        $lines.Add('logmon_profile_matched_files'+$l+' '+$item.MatchedFiles)
        $lines.Add('logmon_profile_unread_bytes'+$l+' '+$item.Backlog)
        foreach ($r in $item.Rules) {
            $rl = Labels $item.Config.Name $r.Config.Name
            $lines.Add('logmon_event_active'+$rl+' '+$r.State.Active)
            $lines.Add('logmon_event_matches_total'+$rl+' '+$r.State.Total)
            $lines.Add('logmon_event_last_match_timestamp_seconds'+$rl+' '+$r.State.LastMatch)
        }
        if ($item.Config.PendingFiles) {
            $lines.Add('logmon_pending_files'+$l+' '+$s.Pending)
            $lines.Add('logmon_pending_files_known'+$l+' '+$s.PendingKnown)
            $lines.Add('logmon_pending_files_observed_timestamp_seconds'+$l+' '+$s.PendingObserved)
            $lines.Add('logmon_pending_files_threshold'+$l+' '+$cfg.PendingFilesThreshold)
        }
    }
    [IO.Directory]::CreateDirectory($cfg.TextfileDirectory) | Out-Null
    # State first: next run can re-publish committed results if metric publication fails.
    $state.BaselineEstablished = $true
    Write-Atomic $statePath ($state | ConvertTo-Json -Depth 30)
    Write-Atomic (Join-Path $cfg.TextfileDirectory $cfg.MetricFileName) (($lines -join "`n")+"`n")
    if (@($work | Where-Object { $_.Success -eq 0 }).Count -gt 0) { exit 2 }
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
} finally { if ($null -ne $lock) { $lock.Dispose() } }

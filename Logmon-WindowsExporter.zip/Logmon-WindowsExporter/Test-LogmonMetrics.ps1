#requires -Version 5.1
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Join-Path ([IO.Path]::GetTempPath()) ('logmon-test-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($root) | Out-Null
$utf8 = New-Object Text.UTF8Encoding($false)
$exe = (Get-Process -Id $PID).Path
$config = Get-Content (Join-Path $PSScriptRoot 'logmon-config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($p in $config.Profiles) {
    $baseName = [IO.Path]::GetFileName($p.Path.Replace('\','/'))
    $p.Path = Join-Path $root $baseName
    [IO.File]::WriteAllText($p.Path.Replace('*','001'),"historical ERROR;`n",$utf8)
}
$config.TextfileDirectory = Join-Path $root 'metrics'
$configPath = Join-Path $root 'config.json'
[IO.File]::WriteAllText($configPath,($config | ConvertTo-Json -Depth 30),$utf8)
$stateDir = Join-Path $root 'state'
$collector = Join-Path $PSScriptRoot 'Collect-LogmonMetrics.ps1'
function Run-Collector([string[]]$Extra = @(), [int]$ExpectedExit = 0) {
    & $exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $collector -ConfigPath $configPath -StateDirectory $stateDir @Extra
    if ($LASTEXITCODE -ne $ExpectedExit) { throw "Unexpected exit code $LASTEXITCODE; expected $ExpectedExit" }
}
function Read-State { return (Get-Content (Join-Path $stateDir 'state.json') -Raw -Encoding UTF8 | ConvertFrom-Json) }
function Find-Rule([string]$Profile,[string]$Watcher) {
    $s = Read-State
    return (($s.Profiles | Where-Object { $_.Name -eq $Profile }).Rules | Where-Object { $_.Name -eq $Watcher })
}
function Assert-True([bool]$Value,[string]$Message) { if (-not $Value) { throw $Message } }
try {
    Run-Collector
    $s = Read-State
    foreach ($p in $s.Profiles) { foreach ($r in $p.Rules) { Assert-True ($r.Total -eq 0) 'Historical lines were processed.' } }
    Write-Host 'PASS: Initial baseline ignores historical errors.'
    $log = Join-Path $root '9999z.log'
    [IO.File]::AppendAllText($log,"The operation has timed out`nAvslutter,`nBatch feilet`nERROR;`n",$utf8)
    Run-Collector
    foreach ($r in ((Read-State).Profiles | Where-Object Name -eq 'StrasakLasting').Rules) {
        Assert-True ($r.Total -eq 1 -and $r.Active -eq 1) 'Pattern match or active state incorrect.'
    }
    Run-Collector
    Assert-True ((Find-Rule 'StrasakLasting' 'ERROR').Total -eq 1) 'Duplicate match after restart.'
    Write-Host 'PASS: All four patterns match once, without replay.'
    [IO.File]::AppendAllText($log,'ERROR; incomplete',$utf8)
    Run-Collector
    Assert-True ((Find-Rule 'StrasakLasting' 'ERROR').Total -eq 1) 'Incomplete line was processed.'
    [IO.File]::AppendAllText($log," completed`n",$utf8)
    Run-Collector
    Assert-True ((Find-Rule 'StrasakLasting' 'ERROR').Total -eq 2) 'Completed line was missed.'
    Write-Host 'PASS: Incomplete trailing line is retained.'
    Run-Collector -Extra @('-ResetProfile','StrasakLasting','-ResetWatcher','ERROR')
    Assert-True ((Find-Rule 'StrasakLasting' 'ERROR').Active -eq 0) 'Reset did not clear alarm.'
    Write-Host 'PASS: Explicit reset clears alarm.'
    $sihdd = Join-Path $root 'SIHdd.log'
    [IO.File]::AppendAllText($sihdd,"Antall filer til behandling: 12`n",$utf8)
    Run-Collector
    Assert-True (((Read-State).Profiles | Where-Object Name -eq 'SIHdd-log').Pending -eq 12) 'SIHdd count missing.'
    [IO.File]::AppendAllText($sihdd,"Antall filer til behandling: 0`n",$utf8)
    Run-Collector
    Assert-True (((Read-State).Profiles | Where-Object Name -eq 'SIHdd-log').Pending -eq 0) 'SIHdd zero missing.'
    Write-Host 'PASS: SIHdd count and zero update.'
    [IO.File]::WriteAllText((Join-Path $root 'PALnew.log'),"Batch feilet`nERROR;`n",$utf8)
    Run-Collector
    Assert-True ((Find-Rule 'PAL-logs' 'ERROR').Total -eq 1) 'New wildcard file was skipped.'
    Write-Host 'PASS: Newly discovered file is read from beginning.'
    [IO.File]::WriteAllText($log,"ERROR;`n",$utf8)
    Run-Collector
    Assert-True ((Find-Rule 'StrasakLasting' 'ERROR').Total -eq 3) 'Truncated file was missed.'
    Move-Item -LiteralPath $log -Destination ($log+'.old')
    [IO.File]::WriteAllText($log,(('x'*100)+"`nERROR;`n"),$utf8)
    Run-Collector
    Assert-True ((Find-Rule 'StrasakLasting' 'ERROR').Total -eq 4) 'Replaced file was missed.'
    Write-Host 'PASS: Truncation and file replacement.'
    Remove-Item -LiteralPath (Join-Path $root 'OVFSI.log')
    Run-Collector -ExpectedExit 2
    $metrics = Get-Content (Join-Path $config.TextfileDirectory 'logmon.prom') -Raw -Encoding UTF8
    Assert-True ($metrics.Contains('logmon_profile_collection_success{profile="OVFSI-log"} 0')) 'Missing-file health metric incorrect.'
    Write-Host 'PASS: Missing log produces health alarm metric.'
    Write-Host "ALL TESTS PASSED. Test files retained at $root"
} catch {
    Write-Warning "Test failed. Files retained at $root"
    throw
}

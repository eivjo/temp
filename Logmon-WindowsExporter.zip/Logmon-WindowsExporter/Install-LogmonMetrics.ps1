#requires -Version 5.1
#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$InstallDirectory = 'C:\ProgramData\windows_exporter\logmon',
    [string]$TaskName = 'windows_exporter-logmon',
    [string]$TextfileDirectory,
    [switch]$ReplaceConfig
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8 = New-Object Text.UTF8Encoding($false)
[IO.Directory]::CreateDirectory($InstallDirectory) | Out-Null
# Only SYSTEM and local Administrators may alter code/state run by SYSTEM.
& icacls.exe $InstallDirectory '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'Could not protect installation directory.' }
$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction Stop
    $deadline = [DateTime]::UtcNow.AddSeconds(20)
    do {
        $running = (Get-ScheduledTask -TaskName $TaskName).State -eq 'Running'
        if ($running) { Start-Sleep -Milliseconds 200 }
    } while ($running -and [DateTime]::UtcNow -lt $deadline)
    if ($running) { throw 'Existing task did not stop. Installation aborted.' }
}
foreach ($name in @('Collect-LogmonMetrics.ps1','logmon-config.json')) {
    $source = Join-Path $PSScriptRoot $name
    $dest = Join-Path $InstallDirectory $name
    if ($name -eq 'logmon-config.json' -and (Test-Path -LiteralPath $dest)) {
        if (-not $ReplaceConfig) { Write-Host 'Keeping existing logmon-config.json'; continue }
        Copy-Item -LiteralPath $dest -Destination ($dest+'.'+[DateTime]::Now.ToString('yyyyMMddHHmmss')+'.bak')
    }
    if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($dest)) {
        Copy-Item -LiteralPath $source -Destination $dest -Force
    }
}
$configPath = Join-Path $InstallDirectory 'logmon-config.json'
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($TextfileDirectory) {
    $config.TextfileDirectory = $TextfileDirectory
    [IO.File]::WriteAllText($configPath,($config | ConvertTo-Json -Depth 30),$utf8)
}
[IO.Directory]::CreateDirectory($config.TextfileDirectory) | Out-Null
# Do not change ACLs on an existing exporter-managed directory.
$exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$script = Join-Path $InstallDirectory 'Collect-LogmonMetrics.ps1'
$state = Join-Path $InstallDirectory 'state'
$arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$script+'" -ConfigPath "'+$configPath+'" -StateDirectory "'+$state+'"'
$action = New-ScheduledTaskAction -Execute $exe -Argument $arguments -WorkingDirectory $InstallDirectory
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1)
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 4)
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Logmon replacement: active log patterns to windows_exporter textfile metrics.' -Force | Out-Null
Write-Host "Installed task: $TaskName (SYSTEM, every minute)."
Write-Host "Config: $configPath"
Write-Host "Metrics: $(Join-Path $config.TextfileDirectory $config.MetricFileName)"
Write-Host 'Running an initial foreground scan. Exit 2 means one or more profiles could not be read.'
& $exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $script -ConfigPath $configPath -StateDirectory $state
$result = $LASTEXITCODE
if ($result -ne 0) { Write-Warning "Initial collector exit code: $result. Review warnings and paths before retiring logmon." }
Write-Host 'The task remains scheduled. No windows_exporter restart is needed if textfile is already enabled for this directory.'

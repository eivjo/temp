# Logmon til PowerShell + windows_exporter

Komplett baseline for de seks aktive profilene i vedlagte Nimsoft-konfigurasjon.
Ingen Java kreves. PowerShell 5.1+ og windows_exporter med textfile-collector kreves.

## Hva følger med?

- `Collect-LogmonMetrics.ps1`: leser nye logglinjer, lagrer posisjon/tilstand og publiserer `.prom`.
- `logmon-config.json`: seks profiler, 16 feilmønstre og SIHdd-antall. De 18 aktive Nimsoft-watcherne blir 16 feilmønstre pluss telling og clear.
- `Install-LogmonMetrics.ps1`: installerer en Scheduled Task som SYSTEM, hvert minutt.
- `Test-LogmonMetrics.ps1`: isolert test med egne filer under TEMP.
- `logmon-alerts.rules.yml`: komplette Prometheus-alarmregler.

## Viktige valg i denne baselinen

1. De 16 feilmønstrene gir **vedvarende alarmer**, frem til eksplisitt nullstilling med collectoren. Ingen tidsbasert friskmelding.
2. **SIHdd: alarm ved antall > 0, friskmelding ved 0.** Dette er et bevisst avvik fra gammel konfigurasjon, som har `lt 3` på felt `11-11`. Uten en virkelig logglinje kan gammel variabeluttrekking ikke bekreftes. Baseline bruker teksten `Antall filer til behandling: <heltall>`. Kontroller dette mot deres faktiske logg før dere avvikler logmon.
3. Første kjøring starter ved slutten av eksisterende logger (`InitialRead: End`). Historiske feil ignoreres. Nye filer oppdaget etter første kjøring leses fra starten. Ved gjenkjent rotasjon/trunkering leses filen fra starten.
4. Alle profiler kontrolleres hvert minutt, også PALOS som tidligere var hvert 30. minutt. Ikke samme pollingfrekvens som Nimsoft.
5. Ingen fullstendige logglinjer sendes til Prometheus. Labels er kun faste profil- og watcher-navn; ikke dynamiske meldinger, tidspunkt eller filnavn. Hver profil/watcher summerer over filene den matcher, som den gamle suppression-ID-en.
6. SIHdd-antall er **sist observerte verdi i loggen**, ikke en direkte katalogtelling. Før første nye antallslinje er `logmon_pending_files_known` 0, og antallsalarmen evalueres ikke som kjent.
7. `PAL*.log` inkluderer også `PALOS.log`. Det kan gi to separate profiler for samme fil, akkurat som kildekonfigurasjonen. Ved flere filer i én profil behandles de etter filnavn; SIHdd har én fil.
8. Filenes innhold tolkes som UTF-8. Bruk eksempelvis `windows-1252` i `Encoding` hvis disse loggene faktisk er ANSI. PS-filene er ASCII, JSON bruker Unicode-escaping, og metrikker er UTF-8 uten BOM.
9. Globale og konfigurasjonsfeil avbryter kjøringen. Lesefeil per fil gir health=0, exitkode 2 og bevarer eksisterende alarmtilstander. En manglende logg varsles etter 5 minutter; dette er strengere enn de gamle profilene med `alarmFOpenFail=no`.

## 1. Pakk ut og kjør isolert test

Pakk ut ZIP-filen under `C:\Robot_nim`, slik at katalogen blir:

`C:\Robot_nim\Logmon-WindowsExporter`

Åpne PowerShell som administrator:

```powershell
Set-Location 'C:\Robot_nim\Logmon-WindowsExporter'
Get-ChildItem -File | Unblock-File
powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\Test-LogmonMetrics.ps1'
```

Testen lager egne midlertidige logger, egen state og egne `.prom`-filer.
Den installerer ingen task og leser ikke produksjonsloggene. Se etter `ALL TESTS PASSED`.
Testfilene beholdes i TEMP for inspeksjon og kan slettes etterpå.

## 2. Kontroller konfigurasjonen

Alle produksjonslogger er under `D:\Datafiler_batch\Felles\LOGG\`:

| Profil | Fil | Feilmønstre |
|---|---|---|
| StrasakLasting | 9999z.log | The operation has timed out / Avslutter, / Batch feilet / ERROR; |
| PALOS | PALOS.log | Feil: TA-Input er tom / TXF-MELDING |
| SSPLasting | 8888ny.log | gikk ikke bra / TXF-MELDING / Batch feilet / ERROR; |
| PAL-logs | PAL*.log | Batch feilet / ERROR; |
| OVFSI-log | OVFSI.log | Batch feilet / ERROR; |
| SIHdd-log | SIHdd.log | Batch feilet / ERROR; / Antall filer til behandling: N |

Mønstrene er regulære uttrykk for delstrengsøk og er konfigurert med `IgnoreCase: false`.
Fjern profiler fra JSON hvis de ikke skal overvåkes på denne serveren.
For å lese historikk fra første kjøring, sett `InitialRead` til `Start` **før installasjonen**.
Dette kan aktivere gamle feil. Endring av `InitialRead` etter etablert state flytter ikke allerede lagrede posisjoner.

`PendingFilesThreshold` er 0. Terskelen kan endres i JSON; Prometheus sammenlikner mot den publiserte terskelen.
Ved terskel 3 vil alarmen være aktiv ved 4 eller flere og friskmeldes ved 3 eller færre.
Dette er ikke en implementering av gammel `lt 3`-logikk.

## 3. Installer

```powershell
Set-Location 'C:\Robot_nim\Logmon-WindowsExporter'
powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\Install-LogmonMetrics.ps1'
```

Installasjonen gjør følgende:

- Legger script og JSON i `C:\ProgramData\windows_exporter\logmon`.
- Begrenser tilgang til installasjonskatalogen til SYSTEM og lokale administratorer.
- Lagrer state i `C:\ProgramData\windows_exporter\logmon\state\state.json`.
- Skriver `C:\Program Files\windows_exporter\textfile_inputs\logmon.prom`.
- Registrerer Scheduled Task `windows_exporter-logmon`, kjører som SYSTEM hvert minutt.
- Kjører en innledende scan i administratorens kontekst; påfølgende task kjører som SYSTEM.

Tilgang må dermed også fungere som SYSTEM. For UNC-filer kreves egen vurdering av maskinkonto/tjenestekonto og share-/NTFS-rettigheter.
Kilden bruker lokale filer, og pakken bruker ingen passord.
En eksisterende JSON beholdes ved ny installasjon. `-ReplaceConfig` tar backup og erstatter den med pakkens fil.

Hvis dere bruker en annen textfile-katalog:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\Install-LogmonMetrics.ps1' -TextfileDirectory 'C:\ProgramData\windows_exporter\textfile_inputs'
```

Dette endrer scriptets utmappe, men ikke exporterens konfigurasjon. De to må peke til samme mappe.
Ikke bruk en innmappe som vanlige brukere kan skrive vilkårlige metrikker til.

## 4. windows_exporter

Dere har allerede textfile aktivert. Behold eksisterende `config.yaml`; ikke erstatt hele filen.
Kontroller at følgende er inkludert i eksisterende oppsett:

```yaml
# collectors.enabled må inneholde textfile sammen med eksisterende collectors.
collector:
  textfile:
    directories:
      - 'C:\Program Files\windows_exporter\textfile_inputs'
```

Ikke opprett to `collector:`-nøkler. Endring av exporter-konfigurasjonen krever omstart av windows_exporter.
Hvis katalogen allerede er konfigurert, plukkes nye `.prom`-filer opp ved neste scrape uten omstart.
Metrikkene er egendefinerte og uavhengige av service-/CPU-endringene mellom exporter 0.31.8 og 0.32.1.

Kontroller lokalt:

```powershell
Get-ScheduledTask -TaskName 'windows_exporter-logmon' | Select-Object TaskName,State
Get-ScheduledTaskInfo -TaskName 'windows_exporter-logmon' |
    Select-Object LastRunTime,LastTaskResult,NextRunTime

(Invoke-WebRequest -Uri 'http://localhost:9182/metrics' -UseBasicParsing).Content -split "`n" |
    Where-Object { $_ -match '^logmon_' }
```

Exitkode 0 = OK, 2 = en eller flere loggprofiler feilet, 1 = alvorlig feil (f.eks. ugyldig JSON eller state).
Task-historikken viser utfall; konkret feilmelding sees ved manuell kjøring:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\ProgramData\windows_exporter\logmon\Collect-LogmonMetrics.ps1'
```

Kjøringen låser state-katalogen. Hvis en annen kjøring pågår, vent og prøv igjen.

## 5. Aktiver alarmreglene

`logmon-alerts.rules.yml` er en **Prometheus-regelfil**, ikke en Grafana dashboard-import eller Grafana provisioning-fil.
Legg den inn i Prometheus sitt eksisterende `rule_files`-oppsett, bevar øvrige regler, valider og reload:

```bash
promtool check rules /etc/prometheus/rules/logmon-alerts.rules.yml
promtool check config /etc/prometheus/prometheus.yml
```

Utfør reload med deres vanlige prosedyre. Prometheus må allerede sende alarmer til Alertmanager.
Reglene beholder Prometheus-targetenes labels som `team`, `pit_env`, `dns`, `instance` og `job`.
Pakken legger ikke inn teamnavn som ikke finnes i kildekonfigurasjonen.
Kontroller at Alertmanager har en passende route for disse target-labelene.

For å oppdage manglende metrikker også før første vellykkede publisering, legg target-label
`logmon_enabled: "true"` på **kun servere der pakken skal kjøre**, i deres eksisterende Prometheus-target-oppsett.
Regelen `WindowsLogmonMetricsMissing` bruker dette. Eksisterende `up == 0`-alarmer må dekke exporter/server nede.

Hvis dere heller ønsker Grafana-administrerte regler i en teammappe, opprett regler der med de samme PromQL-uttrykkene.
Bruk instant query, Reduce Last og terskel > 0 for `logmon_event_active`, og ta med labels og for-tider fra regelfilen.
Ikke aktiver både Prometheus- og Grafana-utgaven for de samme alarmene.

## 6. Nullstill en bekreftet feilhendelse

Eksempel: feilen `ERROR` i `StrasakLasting` er undersøkt og kan lukkes:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\ProgramData\windows_exporter\logmon\Collect-LogmonMetrics.ps1' -ResetProfile 'StrasakLasting' -ResetWatcher 'ERROR'
```

Dette nullstiller bare aktivtilstanden. Historisk teller og siste trefftidsstempel beholdes.
Nye uleste feil etterpå kan aktivere alarmen umiddelbart, også i samme kjøring.
Watchernavnene er de opprinnelige navnene, f.eks. `Batch feilet`, `TimedOut` og `TXF-MELDING`.
SIHdd-antallet kan ikke nullstilles manuelt; en ny logglinje oppdaterer tallet.

**Lukking i IRM nullstiller ikke scriptets tilstand.** Nullstill kilden og lukk deretter IRM-gruppen hvis den bruker manuell lukking.
`resolution_mode` er en label for deres IRM-template; Prometheus gir den ikke egen funksjonalitet.

## Drift og kjente grenser

- Tilstand må ligge lokalt på NTFS, utenfor textfile-mappen. Ikke slett `state.json` som rutine: da mistes tellere/alarmer og første-kjøringspolicy brukes på nytt.
- Atomisk skriving gir `.bak` av forrige state og metrikkfil. Midlertidige filer slutter på `.tmp` og leses ikke som `.prom`.
- Ugyldig state overskrives ikke. Undersøk feilen og gjenopprett eventuelt backup med task stoppet. Backup kan medføre gjentatt lesing av noen linjer.
- Windows file-ID, filstørrelse og hash av de første opptil 256 bytene brukes for rotasjon. Ved copy-truncate og rask gjenvekst med identisk prefiks mellom to kjøringer kan endringen ikke alltid oppdages. Fjernes en rotert fil før scriptet har lest halen, kan linjer gå tapt. Ingen tapsfri leveringsgaranti.
- Bare LF/CRLF-terminerte linjer støttes. Ufullstendig siste linje avventes. UTF-16, CR-only og komprimerte logger støttes ikke.
- Maks 16 MiB leses per fil per kjøring (konfigurerbart opptil 64 MiB). `logmon_profile_unread_bytes` viser etterslep, inkludert ufullstendig linje.
- `last_match` er innsamlingstid, ikke tidspunkt parset fra logglinjen. Etter etterslep kan gamle hendelser fremstå som nylig innsamlet.
- Feilmeldingstekst finnes i JSON som referanse; lange loggmeldinger publiseres ikke som labels.
- Kode/state oppdateres separat fra .prom: ved krasj mellom disse operasjonene republiseres lagret tilstand ved neste kjøring. En krasj før state er lagret kan gi ny gjennomlesing, men ingen nøyaktig-én-gang-garanti.
- Hver fil leses én gang per profil. Profilene har samme navnemønster-overlapp som i Nimsoft.
- SIHdd kan bli stående på en gammel verdi hvis batchen ikke skriver nye antallslinjer. Metrikken `logmon_pending_files_observed_timestamp_seconds` kan brukes til egen ferskhetsalarm tilpasset den faktiske batchplanen; en vilkårlig tidsgrense er ikke lagt inn.

## Avinstaller / tilbake til Nimsoft

Behold Nimsoft parallelt under testen; forvent doble varsler hvis begge sender til samme mottaker.
Når dere har validert en kontrollert loggfeil, clear, task-kontekst og Alertmanager-route, kan de tilsvarende Nimsoft-profilene deaktiveres.

For å stoppe den nye løsningen:

```powershell
Stop-ScheduledTask -TaskName 'windows_exporter-logmon'
Unregister-ScheduledTask -TaskName 'windows_exporter-logmon' -Confirm:$false
Remove-Item -LiteralPath 'C:\Program Files\windows_exporter\textfile_inputs\logmon.prom' -ErrorAction SilentlyContinue
```

Ta samtidig bort alarmreglene og `logmon_enabled`-labelen for å unngå mangler-alarm.
Behold state som historikk eller slett installasjonskatalogen etter deres vanlige rutine.

## Utført validering og begrensninger

- PowerShell-filene er syntakskontrollert med PowerShell 7.7.
- Isolerte funksjonstester er kjørt i PowerShell 7.7 på Linux: oppstart uten historikk, nye treff, ingen dobbelttelling ved omstart, ufullstendige linjer, eksplisitt reset, SIHdd-antall/clear, nye wildcard-filer, trunkering/erstatning og manglende fil.
- En ekstra test bekrefter at ugyldig state avbryter uten å overskrive eksisterende metrikker.
- Prometheus-eksponeringsformat er kontrollert med parser.
- `promtool check rules` og `promtool test rules` er kjørt med Prometheus 3.16.0. Testene dekker alle fem alarmreglene.
- Windows Scheduled Task, NTFS-rettigheter, Windows file-ID-kallet og faktisk PowerShell 5.1-kjøring er **ikke kjørt i dette miljøet**. Kjør medfølgende test på aktuell Windows-server og kontroller SYSTEM-kjøringen før produksjonsovergang.

Test Prometheus-reglene selv:

```bash
promtool check rules logmon-alerts.rules.yml
promtool test rules tests/prometheus.rules.test.yml
```

Referanser:

- https://github.com/prometheus-community/windows_exporter/blob/main/docs/collector.textfile.md
- https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/

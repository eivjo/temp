
#!/usr/bin/env python3
"""Cisco MDT GPB-KV simulator for Telegraf."""

import argparse
import json
import sys
import threading
import time
from pathlib import Path

import grpc
from google.protobuf import json_format

import mdt_dialout_pb2
import mdt_dialout_pb2_grpc
import telemetry_bis_pb2


def main():
    parser = argparse.ArgumentParser(
        description="Simulate Cisco MDT gRPC dial-out telemetry"
    )
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=443)
    parser.add_argument("--packet", default="packet.json")
    parser.add_argument("--interval", type=float, default=10)
    parser.add_argument("--count", type=int, default=30)
    parser.add_argument("--source", default="ubuntu-mdt-test")
    parser.add_argument(
        "--path",
        default="type:model/some/path",
        help="Cisco MDT encoding path"
    )
    parser.add_argument(
        "--ca",
        help="Optional PEM file containing the trusted CA"
    )
    args = parser.parse_args()

    with open(args.packet, encoding="utf-8") as f:
        packet = json.load(f)

    packet["nodeIdStr"] = args.source
    packet["encodingPath"] = args.path

    # Check protobuf JSON before connecting
    test_msg = json_format.ParseDict(
        packet, telemetry_bis_pb2.Telemetry()
    )
    print(
        f"Protobuf OK: {len(test_msg.data_gpbkv)} "
        "GPB-KV records",
        flush=True
    )

    ca_bytes = (
        Path(args.ca).read_bytes() if args.ca else None
    )
    credentials = grpc.ssl_channel_credentials(
        root_certificates=ca_bytes
    )

    channel = grpc.secure_channel(
        f"{args.host}:{args.port}",
        credentials,
        options=[
            ("grpc.keepalive_time_ms", 60000),
            ("grpc.keepalive_timeout_ms", 20000),
        ],
    )

    print(
        f"Connecting to {args.host}:{args.port}...",
        flush=True
    )

    try:
        grpc.channel_ready_future(channel).result(timeout=15)
    except grpc.FutureTimeoutError:
        print("ERROR: gRPC connection timeout")
        sys.exit(1)

    print("gRPC channel READY", flush=True)

    stub = mdt_dialout_pb2_grpc.gRPCMdtDialoutStub(channel)
    stop_event = threading.Event()

    def generate():
        for i in range(args.count):
            if stop_event.is_set():
                break

            # Use current timestamp in milliseconds
            packet["msgTimestamp"] = str(
                int(time.time() * 1000)
            )

            telemetry = json_format.ParseDict(
                packet, telemetry_bis_pb2.Telemetry()
            )

            request = mdt_dialout_pb2.MdtDialoutArgs()
            request.ReqId = i + 1
            request.data = telemetry.SerializeToString()

            print(
                f"[{i+1}/{args.count}] "
                f"Sending {len(request.data)} bytes "
                f"source={args.source} "
                f"path={args.path}",
                flush=True
            )

            yield request

            if i + 1 < args.count:
                if stop_event.wait(args.interval):
                    break

    try:
        responses = stub.MdtDialout(generate())

        for response in responses:
            print(f"Server response: {response}", flush=True)

        print("gRPC stream completed", flush=True)

    except grpc.RpcError as e:
        print(
            f"gRPC ERROR: {e.code()}\n"
            f"Details: {e.details()}",
            file=sys.stderr
        )
        sys.exit(1)

    except KeyboardInterrupt:
        print("\nInterrupted", flush=True)

    finally:
        stop_event.set()
        channel.close()


if __name__ == "__main__":
    main()

